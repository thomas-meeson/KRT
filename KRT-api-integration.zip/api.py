"""api.py  (EIE) -- serves the backtest outputs and the demo, entirely from localhost (no internet needed).

    pip install -r requirements.txt
    uvicorn api:app --port 8000
    open http://127.0.0.1:8000/          (interactive demo: demo/live.html)
         http://127.0.0.1:8000/demo/     (the guided walkthrough: demo/index.html)

Every data file is read once at startup and cached; restart uvicorn after re-running backtest.py.

Endpoints:
    GET /api/demo              the whole replay file, demo.json (INTERFACES.md section 4)
    GET /api/hours             list of replay hours with both hit rates (for the counter / timeline)
    GET /api/hours/{i}         one replay hour: leaderboard of top pages, cached green/red
    GET /api/spikes            the spike stories
    GET /api/summary           the replay file's summary
    GET /api/results           out/results.csv as JSON (optionally ?horizon=1&cache_size=10000)
    GET /api/options           cache sizes and horizons that have results               (demo_api.py)
    GET /api/compare           ?cache_size=100000&horizon=1: XGBoost vs standard rule vs perfect
                               foresight, 95% intervals, % fewer misses, hours won, per-hour series
    GET /api/pages             ?q=tom&limit=10: autocomplete over pages in the replay day
    GET /api/page/{title}      one page's replay day: views, cache status, spike story
    GET /charts/<file>         the PNGs in out/charts/
    GET /out/<file>            published outputs (CSV downloads, reports, charts)
    GET /demo.json             the replay file (the guided walkthrough fetches ../demo.json)
    GET /demo/...              the front end (demo/)
    GET /                      redirects to the interactive demo
"""
from __future__ import annotations

import json
from contextlib import asynccontextmanager
from pathlib import Path

import pandas as pd
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles

import demo_api
from demo_api import demo_path, load_demo

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "out"


@asynccontextmanager
async def lifespan(_app):
    try:
        demo_api.warm()                  # read every data file once, before the first request
    except HTTPException as e:           # a missing file: only the endpoints that need it return 503
        print(f"warning: {e.detail}")
    yield


app = FastAPI(title="Ahead of the Spike", lifespan=lifespan)
# The demo may be served from another port (e.g. a Vite/React dev server), so allow any origin.
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["GET"], allow_headers=["*"])


def demo() -> dict:
    return load_demo()


_results_df = None


def results_df() -> pd.DataFrame:
    global _results_df
    if _results_df is None:
        path = OUT / "results.csv"
        if not path.exists():
            raise HTTPException(503, "out/results.csv not found; run python backtest.py first")
        _results_df = pd.read_csv(path)
    return _results_df


@app.get("/api/demo")
def get_demo():
    return demo()


@app.get("/api/hours")
def get_hours():
    d = demo()
    return {"day": d["day"], "predictors": d["predictors"], "our_model_name": d.get("our_model_name"),
            "cache_size": d["cache_size"],
            "hours": [{"i": i, "hour": h["hour"], "hit_rate": h["hit_rate"], "total_views": h["total_views"]}
                      for i, h in enumerate(d["hours"])]}


@app.get("/api/hours/{i}")
def get_hour(i: int):
    hours = demo()["hours"]
    if not 0 <= i < len(hours):
        raise HTTPException(404, f"hour index must be 0..{len(hours) - 1}")
    return hours[i]


@app.get("/api/spikes")
def get_spikes():
    return demo()["spikes"]


@app.get("/api/summary")
def get_summary():
    d = demo()
    return {"our_model_name": d.get("our_model_name"), **d["summary"]}


@app.get("/api/results")
def get_results(horizon: int | None = None, cache_size: int | None = None):
    df = results_df()
    if horizon is not None:
        df = df[df["horizon"] == horizon]
    if cache_size is not None:
        df = df[df["cache_size"] == cache_size]
    return json.loads(df.to_json(orient="records"))


app.include_router(demo_api.router)


@app.get("/demo.json", include_in_schema=False)
def get_demo_file():
    return FileResponse(demo_path(), media_type="application/json")


@app.get("/", include_in_schema=False)
def index():
    return RedirectResponse("/demo/live.html" if (ROOT / "demo" / "live.html").exists() else "/demo/")


if (OUT / "charts").is_dir():
    app.mount("/charts", StaticFiles(directory=OUT / "charts"), name="charts")
if OUT.is_dir():
    app.mount("/out", StaticFiles(directory=OUT), name="out")
if (ROOT / "demo").is_dir():
    app.mount("/demo", StaticFiles(directory=ROOT / "demo", html=True), name="demo")
