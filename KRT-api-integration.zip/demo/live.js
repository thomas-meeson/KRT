'use strict';
// Interactive demo driven by the local API (api.py + demo_api.py). Every number shown is a value
// returned by the API, which reads the published files. Missing values show as "Not available".

const $ = id => document.getElementById(id);
const fmtInt = new Intl.NumberFormat('en-GB');
const fmtPct = new Intl.NumberFormat('en-GB', { style: 'percent', minimumFractionDigits: 2, maximumFractionDigits: 2 });
const fmtTime = new Intl.DateTimeFormat('en-GB', { timeZone: 'UTC', day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit', hourCycle: 'h23' });
const NA = 'Not available';
const isNum = v => typeof v === 'number' && Number.isFinite(v);
const pct = v => isNum(v) ? fmtPct.format(v) : NA;
const utc = iso => `${fmtTime.format(new Date(iso))} UTC`;
const SVGNS = 'http://www.w3.org/2000/svg';

function el(tag, text, className) {
  const n = document.createElement(tag);
  if (text !== undefined && text !== null) n.textContent = text;
  if (className) n.className = className;
  return n;
}
function svgEl(tag, attrs = {}, text) {
  const n = document.createElementNS(SVGNS, tag);
  for (const [k, v] of Object.entries(attrs)) n.setAttribute(k, String(v));
  if (text !== undefined) n.textContent = text;
  return n;
}
async function api(path) {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), 8000);
  try {
    const res = await fetch(path, { signal: ctrl.signal, cache: 'no-store' });
    let body = null;
    try { body = await res.json(); } catch { /* non-JSON error */ }
    if (!res.ok) { const e = new Error(body?.detail || `HTTP ${res.status}`); e.status = res.status; throw e; }
    return body;
  } finally { clearTimeout(timer); }
}
function showStatus(message, isError = false) {
  $('status').textContent = message;
  $('status').className = `status${isError ? ' error' : ''}`;
  $('status').hidden = !message;
  $('retry').hidden = !isError;
}

/* ------------------------------------------------------------------ navigation */
const VIEWS = { explorer: 'explorer-title', replay: 'replay-title', lookup: 'lookup-title' };
function parseHash() {
  const [view, ...rest] = decodeURIComponent(location.hash.slice(1)).split('/');
  return { view: Object.hasOwn(VIEWS, view) ? view : 'explorer', arg: rest.join('/') };
}
function showView(view, { focus = true } = {}) {
  if (!Object.hasOwn(VIEWS, view)) view = 'explorer';
  if (view !== 'replay') pauseReplay();
  document.querySelectorAll('[data-view]').forEach(s => { s.hidden = s.dataset.view !== view; });
  document.querySelectorAll('.journey-nav [data-go]').forEach(a => a.toggleAttribute('aria-current', a.dataset.go === view));
  document.querySelectorAll('.journey-nav [aria-current]').forEach(a => a.setAttribute('aria-current', 'page'));
  $('article-sidebar').classList.remove('is-open');
  $('contents-toggle').setAttribute('aria-expanded', 'false');
  if (view === 'replay') ensureReplay();
  if (view === 'lookup') ensureLookup();
  if (focus) { window.scrollTo({ top: 0 }); $(VIEWS[view]).focus({ preventScroll: true }); }
}
function go(view, arg = '') {
  const hash = `#${view}${arg ? '/' + encodeURIComponent(arg) : ''}`;
  if (location.hash !== hash) history.pushState(null, '', hash);
  route();
}
function route() {
  const { view, arg } = parseHash();
  showView(view);
  if (view === 'lookup' && arg) lookupPage(arg);
}
document.querySelectorAll('[data-go]').forEach(a => a.addEventListener('click', e => { e.preventDefault(); go(a.dataset.go); }));
window.addEventListener('popstate', route);
$('contents-toggle').addEventListener('click', () => {
  const open = $('contents-toggle').getAttribute('aria-expanded') !== 'true';
  $('contents-toggle').setAttribute('aria-expanded', String(open));
  $('article-sidebar').classList.toggle('is-open', open);
});
$('header-search').addEventListener('submit', e => {
  e.preventDefault();
  const q = $('header-query').value.trim();
  if (!q) return go('lookup');
  $('lookup-query').value = q;
  go('lookup', q);
});

/* ------------------------------------------------------------------ 1. decision explorer */
const cmp = { size: 100000, horizon: 1, options: null, request: 0 };
const COLORS = { last_hour: '#202122', xgboost: '#36c', oracle: '#a2a9b1' };
const DASH = { last_hour: '', xgboost: '', oracle: '6 5' };
const ORDER = ['last_hour', 'xgboost', 'oracle'];

function radios(container, name, values, selected, label, onChange) {
  container.querySelectorAll('label').forEach(l => l.remove());
  for (const v of values) {
    const lab = el('label');
    const input = el('input');
    Object.assign(input, { type: 'radio', name, value: String(v), checked: v === selected });
    input.addEventListener('change', () => { if (input.checked) onChange(v); });
    lab.append(input, el('span', label(v)));
    container.append(lab);
  }
}

async function initExplorer() {
  cmp.options = await api('/api/options');
  if (!cmp.options.cache_sizes.includes(cmp.size)) cmp.size = cmp.options.cache_sizes.at(-1);
  if (!cmp.options.horizons.includes(cmp.horizon)) cmp.horizon = cmp.options.horizons[0];
  radios($('size-picker'), 'cache-size', cmp.options.cache_sizes, cmp.size, v => `${fmtInt.format(v)} articles`, v => { cmp.size = v; loadCompare(); });
  radios($('ahead-picker'), 'hours-ahead', cmp.options.horizons, cmp.horizon, v => `${v} ${v === 1 ? 'hour' : 'hours'}`, v => { cmp.horizon = v; loadCompare(); });
  await loadCompare();
}

async function loadCompare() {
  const id = ++cmp.request;
  let data;
  try { data = await api(`/api/compare?cache_size=${cmp.size}&horizon=${cmp.horizon}`); }
  catch (e) { if (id === cmp.request) showStatus(`Could not load this comparison: ${e.message}`, true); return; }
  if (id !== cmp.request) return;           // a newer selection has already been requested
  showStatus('');
  renderScores(data);
  renderVersus(data);
  renderHourly(data);
}

function renderScores(data) {
  const box = $('cmp-scores');
  box.replaceChildren();
  for (const key of ORDER) {
    const m = data.methods[key];
    const card = el('div', undefined, `horizon-score${key === 'oracle' ? ' oracle' : ''}`);
    card.append(el('h3', m?.label ?? key));
    card.append(el('p', pct(m?.hit_rate), 'interactive-rate'));
    card.append(el('p', isNum(m?.ci_low) && isNum(m?.ci_high) ? `95% interval ${pct(m.ci_low)} to ${pct(m.ci_high)}` : '95% interval not available', 'ci'));
    if (isNum(m?.hit_rate)) {
      const meter = el('div', undefined, 'interactive-meter');
      meter.setAttribute('role', 'meter');
      meter.setAttribute('aria-label', `${m.label}: views served from cache`);
      meter.setAttribute('aria-valuemin', '0');
      meter.setAttribute('aria-valuemax', '100');
      meter.setAttribute('aria-valuenow', String(m.hit_rate * 100));
      const fill = el('span');
      fill.style.width = `${m.hit_rate * 100}%`;
      meter.append(fill);
      card.append(meter);
    }
    card.append(el('p', key === 'oracle' ? 'ceiling: knows the future, not usable in practice' : 'average share of views served from cache', 'metric-note'));
    box.append(card);
  }
}

function finding(title, value, caption) {
  const item = el('div', undefined, 'finding');
  item.append(el('h3', title), el('p', value ?? NA, `finding-value${value == null ? ' na' : ''}`), el('p', caption));
  return item;
}
function signed(v, digits, unit = '') { return isNum(v) ? `${v >= 0 ? '+' : '−'}${Math.abs(v).toFixed(digits)}${unit}` : null; }

function renderVersus(data) {
  const v = data.versus_standard;
  const box = $('cmp-findings');
  box.replaceChildren();
  if (!v) {
    box.append(finding('Comparison', null, 'Paired comparison not available for this setting.'));
    $('cmp-versus-note').textContent = '';
    return;
  }
  const fewer = isNum(v.miss_reduction_pct) ? `${Math.abs(v.miss_reduction_pct).toFixed(1)}%` : null;
  box.append(
    finding(v.miss_reduction_pct < 0 ? 'More cache misses' : 'Fewer cache misses', fewer,
      `${v.miss_reduction_pct < 0 ? 'more' : 'fewer'} requests sent to the main servers than the standard rule (misses ${pct(v.miss_rate)} vs ${pct(v.standard_miss_rate)})`),
    finding('Hit-rate gain', signed(v.gain_pts, 2, ' pts'),
      isNum(v.paired_ci_low_pts) && isNum(v.paired_ci_high_pts) ? `percentage points; paired 95% interval ${signed(v.paired_ci_low_pts, 2)} to ${signed(v.paired_ci_high_pts, 2)}` : 'percentage points'),
    finding('Hours won', `${v.hours_won} of ${v.hours}`,
      `test hours where our model served more views${v.hours_lost ? `; lost ${v.hours_lost}` : '; lost none'}`),
    finding('Gap to perfect foresight closed', isNum(v.gap_closed_pct) ? `${Math.round(v.gap_closed_pct)}%` : null,
      'of the distance from the standard rule to the ceiling'));
  $('cmp-versus-note').textContent = `Both methods hold ${fmtInt.format(data.cache_size)} articles and decide ${data.horizon} ${data.horizon === 1 ? 'hour' : 'hours'} ahead, scored on the same ${v.hours} test hours. Values from ${v.source}.`;
}

function renderHourly(data) {
  const s = data.hourly;
  const svg = $('cmp-chart');
  svg.replaceChildren();
  $('cmp-legend').replaceChildren();
  const n = s?.target_hours?.length || 0;
  $('cmp-hourly-copy').textContent = n
    ? `Hit rate in each of the ${n} test hours, ${fmtInt.format(data.cache_size)} articles, deciding ${data.horizon} ${data.horizon === 1 ? 'hour' : 'hours'} ahead. Hover a point for exact values.`
    : 'Hour-by-hour results are not available for this setting.';
  if (!n) { $('cmp-scale').textContent = ''; return; }
  const values = ORDER.flatMap(k => s[k].filter(isNum));
  let lo = Math.max(0, Math.floor((Math.min(...values) - 0.005) * 50) / 50);
  let hi = Math.min(1, Math.ceil((Math.max(...values) + 0.005) * 50) / 50);
  const L = 65, R = 735, T = 30, B = 270;
  const x = i => L + (n === 1 ? 0 : i / (n - 1)) * (R - L);
  const y = v => B - (v - lo) / (hi - lo) * (B - T);
  svg.append(svgEl('title', { id: 'cmp-chart-title' }, 'Cache hit rate in each test hour'),
    svgEl('desc', {}, `Hourly hit rates for the standard rule, our model and perfect foresight. Vertical axis from ${pct(lo)} to ${pct(hi)}.`));
  for (let k = 0; k <= 4; k++) {
    const v = lo + k * (hi - lo) / 4;
    svg.append(svgEl('line', { x1: L, x2: R, y1: y(v), y2: y(v), stroke: '#eaecf0' }),
      svgEl('text', { x: L - 8, y: y(v) + 4, 'text-anchor': 'end' }, `${(v * 100).toFixed(1)}%`));
  }
  // Day ticks at each UTC midnight.
  s.target_hours.forEach((h, i) => {
    if (h.slice(11, 13) !== '00') return;
    svg.append(svgEl('line', { x1: x(i), x2: x(i), y1: T, y2: B, stroke: '#c8ccd1', 'stroke-dasharray': '2 4' }),
      svgEl('text', { x: x(i), y: B + 18, 'text-anchor': 'middle' }, fmtTime.format(new Date(h)).slice(0, 6)));
  });
  svg.append(svgEl('text', { x: (L + R) / 2, y: 320, 'text-anchor': 'middle' }, 'Test hour (UTC)'));
  for (const key of ORDER) {
    let d = '', joined = false;
    s[key].forEach((v, i) => { if (!isNum(v)) { joined = false; return; } d += `${joined ? 'L' : 'M'}${x(i).toFixed(1)} ${y(v).toFixed(1)} `; joined = true; });
    svg.append(svgEl('path', { d, fill: 'none', stroke: COLORS[key], 'stroke-width': key === 'xgboost' ? 2.5 : 2, 'stroke-dasharray': DASH[key] }));
    const m = data.methods[key];
    const li = el('li');
    const sw = el('span', key === 'oracle' ? '┅' : '━', 'series-swatch');
    sw.style.color = COLORS[key];
    sw.setAttribute('aria-hidden', 'true');
    li.append(sw, document.createTextNode(`${m?.label ?? key}${key === 'oracle' ? ' (dashed)' : ''}`));
    $('cmp-legend').append(li);
  }
  // Hover targets: one transparent column per hour with every method's exact value.
  const w = (R - L) / Math.max(n - 1, 1);
  s.target_hours.forEach((h, i) => {
    const col = svgEl('rect', { x: x(i) - w / 2, y: T, width: w, height: B - T, fill: 'transparent' });
    col.append(svgEl('title', {}, `${utc(h)}\n` + ORDER.map(k => `${data.methods[k]?.label ?? k}: ${pct(s[k][i])}`).join('\n')));
    svg.append(col);
  });
  $('cmp-scale').textContent = `Vertical axis zoomed to ${pct(lo)}–${pct(hi)} so hourly differences are visible; it does not start at zero. Source: ${s.source}.`;
}

/* ------------------------------------------------------------------ 2. replay */
const rp = { data: null, i: 0, timer: null, all: false, loading: null };
const FRAME_MS = 1500;

async function ensureReplay() {
  if (rp.data) return;
  rp.loading ||= api('/api/demo').then(d => {
    if (!Array.isArray(d?.hours) || !d.hours.length) throw new Error('the replay file has no hours');
    d.hours.sort((a, b) => a.hour.localeCompare(b.hour));
    rp.data = d;
    const model = d.our_model_name === 'xgboost' ? 'XGBoost' : d.our_model_name;
    $('replay-scope-title').textContent = `${fmtInt.format(d.cache_size)} article spaces. Choices made 1 hour ahead. ${d.day}, UTC.`;
    $('replay-scope-text').textContent = `This is the cache size the replay file records article by article. The decision explorer covers every size and planning time as averages. Our model is ${model}.`;
    $('r-capacity').textContent = `Space for ${fmtInt.format(d.cache_size)} articles`;
    $('r-timeline').max = String(d.hours.length - 1);
    $('r-start').textContent = `${d.hours[0].hour.slice(11, 16)} UTC`;
    $('r-end').textContent = `${d.hours.at(-1).hour.slice(11, 16)} UTC`;
    renderReplay();
  }).catch(e => { rp.loading = null; showStatus(`Could not load the replay: ${e.message}`, true); });
  return rp.loading;
}

function label(key) {
  if (key === 'last_hour') return 'Standard rule';
  if (key === 'our_model') return rp.data?.our_model_name === 'xgboost' ? 'Our model (XGBoost)' : 'Our model';
  return key;
}
function badge(cached) {
  if (cached === true) return el('span', '✓ Ready', 'badge');
  if (cached === false) return el('span', '× Missed', 'badge missed');
  return el('span', '—', 'badge na');
}

function renderReplay() {
  const d = rp.data;
  if (!d) return;
  const h = d.hours[rp.i];
  const playing = rp.timer !== null;
  $('r-hour').dateTime = h.hour;
  $('r-hour').textContent = utc(h.hour);
  $('r-interval').textContent = `Views from ${h.hour.slice(11, 16)} to ${h.hour.slice(11, 13)}:59 UTC · hour ${rp.i + 1} of ${d.hours.length} · ${isNum(h.total_views) ? fmtInt.format(h.total_views) + ' recorded views' : 'total views not available'}`;
  $('r-timeline').value = String(rp.i);
  $('r-timeline').setAttribute('aria-valuetext', utc(h.hour));
  $('r-prev').disabled = rp.i === 0;
  $('r-next').disabled = rp.i === d.hours.length - 1;
  $('r-play').textContent = playing ? 'Pause' : rp.i === d.hours.length - 1 ? 'Replay day' : 'Play';
  $('r-state').textContent = playing ? 'Playing' : rp.i === d.hours.length - 1 ? 'End of day' : 'Paused';

  const perf = $('r-performance');
  perf.replaceChildren();
  for (const key of d.predictors) {
    const v = h.hit_rate?.[key];
    const card = el('section', undefined, 'model');
    const lab = el('h3', label(key), 'model-label');
    lab.append(el('span', key === 'last_hour' ? 'Keeps the most-read articles of the latest hour' : 'Keeps the articles it forecasts will be read'));
    card.append(lab, el('p', pct(v), `rate${isNum(v) ? '' : ' unavailable'}`));
    if (isNum(v)) {
      const meter = el('div', undefined, 'meter');
      const fill = el('div', undefined, 'meter-fill');
      fill.style.width = `${v * 100}%`;
      meter.append(fill);
      card.append(meter);
    }
    perf.append(card);
  }

  const pages = [...(h.top_pages || [])].sort((a, b) => b.views - a.views);
  const ready = key => pages.filter(p => p.cached?.[key] === true).length;
  $('r-ready').textContent = pages.length
    ? `Of these ${pages.length} most-read articles, ${d.predictors.map(k => `${label(k)} had ${ready(k)} ready`).join(' and ')}. The percentages above count every view that hour, not only these articles.`
    : '';

  const head = el('tr');
  for (const [t, c] of [['#', 'rank'], ['Article', ''], ['Views', 'views'], ...d.predictors.map(k => [label(k), 'cache'])]) {
    const th = el('th', t, c); th.scope = 'col'; head.append(th);
  }
  $('r-head').replaceChildren(head);
  const body = $('r-body');
  body.replaceChildren();
  const shown = rp.all ? pages : pages.slice(0, 10);
  shown.forEach((p, idx) => {
    const tr = el('tr');
    const th = el('th');
    th.scope = 'row';
    const link = el('button', p.page.replaceAll('_', ' '), 'row-link');
    link.type = 'button';
    link.title = 'See this article across the day';
    link.addEventListener('click', () => { $('lookup-query').value = p.page.replaceAll('_', ' '); go('lookup', p.page); });
    th.append(link, el('span', `${fmtInt.format(p.views)} views`, 'article-views-mobile'));
    tr.append(el('td', String(idx + 1).padStart(2, '0'), 'rank'), th, el('td', fmtInt.format(p.views), 'views'));
    for (const key of d.predictors) { const td = el('td', undefined, 'cache'); td.append(badge(p.cached?.[key])); tr.append(td); }
    body.append(tr);
  });
  $('r-all').hidden = pages.length <= 10;
  $('r-all').textContent = rp.all ? 'Show top 10' : `Show all ${pages.length}`;
  $('r-all').setAttribute('aria-expanded', String(rp.all));
}

function selectReplayHour(i) {
  if (!rp.data) return;
  pauseReplay();
  rp.i = Math.max(0, Math.min(rp.data.hours.length - 1, i));
  renderReplay();
  $('r-announce').textContent = `Selected ${utc(rp.data.hours[rp.i].hour)}.`;
}
function pauseReplay() {
  if (rp.timer !== null) { clearInterval(rp.timer); rp.timer = null; }
  if (rp.data) renderReplay();
}
function togglePlay() {
  if (!rp.data) return;
  if (rp.timer !== null) { pauseReplay(); return; }
  if (rp.i === rp.data.hours.length - 1) rp.i = 0;
  rp.timer = setInterval(() => {
    rp.i += 1;
    if (rp.i >= rp.data.hours.length - 1) { rp.i = rp.data.hours.length - 1; clearInterval(rp.timer); rp.timer = null; }
    renderReplay();
  }, FRAME_MS);
  renderReplay();
}
$('r-prev').addEventListener('click', () => selectReplayHour(rp.i - 1));
$('r-next').addEventListener('click', () => selectReplayHour(rp.i + 1));
$('r-play').addEventListener('click', togglePlay);
$('r-timeline').addEventListener('input', e => selectReplayHour(Number(e.target.value)));
$('r-all').addEventListener('click', () => { rp.all = !rp.all; renderReplay(); });
document.addEventListener('visibilitychange', () => { if (document.hidden) pauseReplay(); });

/* ------------------------------------------------------------------ 3. page lookup */
const lk = { current: null, suggestTimer: null, suggestId: 0, active: -1, quickLoaded: false };

async function ensureLookup() {
  if (lk.quickLoaded) return;
  lk.quickLoaded = true;
  try {
    const res = await api('/api/pages?limit=12');
    $('lookup-scope').textContent = res.scope;
    const box = $('lookup-quick');
    box.replaceChildren(el('strong', 'Articles with a spike story on the replay day'));
    for (const p of res.pages.filter(p => p.has_spike)) {
      const b = el('button', p.title, 'secondary');
      b.type = 'button';
      b.addEventListener('click', () => { $('lookup-query').value = p.title; go('lookup', p.page); });
      box.append(b);
    }
  } catch (e) { lk.quickLoaded = false; $('lookup-scope').textContent = `Suggestions unavailable: ${e.message}`; }
}

function closeSuggestions() {
  $('lookup-suggestions').hidden = true;
  $('lookup-query').setAttribute('aria-expanded', 'false');
  $('lookup-query').removeAttribute('aria-activedescendant');
  lk.active = -1;
}
async function suggest(q) {
  const id = ++lk.suggestId;
  if (!q.trim()) return closeSuggestions();
  let res;
  try { res = await api(`/api/pages?q=${encodeURIComponent(q)}&limit=8`); } catch { return closeSuggestions(); }
  if (id !== lk.suggestId) return;
  const list = $('lookup-suggestions');
  list.replaceChildren();
  if (!res.pages.length) {
    const li = el('li', 'No page in the replay day matches');
    li.setAttribute('aria-disabled', 'true');
    list.append(li);
  }
  res.pages.forEach((p, i) => {
    const li = el('li', p.title);
    li.id = `suggestion-${i}`;
    li.setAttribute('role', 'option');
    li.dataset.page = p.page;
    li.append(el('span', `${p.hours_in_top_50} h in top 50${p.has_spike ? ' · spike' : ''}`));
    li.addEventListener('mousedown', e => { e.preventDefault(); pick(p); });
    list.append(li);
  });
  list.hidden = false;
  $('lookup-query').setAttribute('aria-expanded', 'true');
}
function pick(p) {
  $('lookup-query').value = p.title;
  closeSuggestions();
  go('lookup', p.page);
}
$('lookup-query').addEventListener('input', e => {
  clearTimeout(lk.suggestTimer);
  lk.suggestTimer = setTimeout(() => suggest(e.target.value), 120);
});
$('lookup-query').addEventListener('keydown', e => {
  const items = [...$('lookup-suggestions').querySelectorAll('[role="option"]')];
  if (e.key === 'Escape') return closeSuggestions();
  if (!items.length || $('lookup-suggestions').hidden || !['ArrowDown', 'ArrowUp', 'Enter'].includes(e.key)) return;
  if (e.key === 'Enter') {
    if (lk.active >= 0) { e.preventDefault(); pick({ page: items[lk.active].dataset.page, title: items[lk.active].firstChild.textContent }); }
    return;
  }
  e.preventDefault();
  lk.active = (lk.active + (e.key === 'ArrowDown' ? 1 : -1) + items.length) % items.length;
  items.forEach((li, i) => li.setAttribute('aria-selected', String(i === lk.active)));
  $('lookup-query').setAttribute('aria-activedescendant', items[lk.active].id);
});
$('lookup-query').addEventListener('blur', () => setTimeout(closeSuggestions, 100));
$('lookup-form').addEventListener('submit', e => {
  e.preventDefault();
  closeSuggestions();
  const q = $('lookup-query').value.trim();
  if (q) go('lookup', q.replaceAll(' ', '_'));
});

async function lookupPage(title) {
  const msg = $('lookup-message');
  let page;
  try { page = await api(`/api/page/${encodeURIComponent(title.replaceAll(' ', '_'))}`); }
  catch (e) {
    $('lookup-result').hidden = true;
    msg.textContent = e.status === 404 ? `${e.message} Try a suggestion above.` : `Could not look up this page: ${e.message}`;
    msg.hidden = false;
    return;
  }
  msg.hidden = true;
  lk.current = page;
  if (!$('lookup-query').value) $('lookup-query').value = page.title;
  renderPage(page);
}

function renderPage(p) {
  $('lookup-result').hidden = false;
  $('lookup-name').textContent = p.title;
  const recorded = p.timeline.filter(t => isNum(t.views));
  const inDay = p.timeline.filter(t => t.in_replay_day && t.cached);
  const peak = recorded.reduce((best, t) => (!best || t.views > best.views ? t : best), null);
  $('lookup-summary').textContent = `In the top 50 for ${p.hours_in_top_50} of 24 hours on ${p.day}.` +
    (peak ? ` Highest recorded: ${fmtInt.format(peak.views)} views at ${utc(peak.hour)}.` : '') +
    ` Cache status: ${fmtInt.format(p.cache_size)} article spaces, chosen ${p.horizon} hour ahead.`;
  $('lookup-model-col').textContent = p.our_model_name === 'xgboost' ? 'Our model (XGBoost)' : 'Our model';

  const firstTop = inDay[0];
  const jump = $('lookup-jump');
  jump.disabled = !firstTop;
  jump.textContent = firstTop ? `Show ${firstTop.hour.slice(11, 16)} UTC in the replay` : 'Not in any replay leaderboard';
  jump.onclick = async () => {
    if (!firstTop) return;
    go('replay');
    await ensureReplay();
    const spikeHour = p.spikes.map(s => s.spike_hour).find(h => inDay.some(t => t.hour === h));
    const target = spikeHour || firstTop.hour;
    selectReplayHour(rp.data.hours.findIndex(h => h.hour === target));
  };

  drawPageChart(p);

  const spikes = $('lookup-spikes');
  spikes.replaceChildren();
  if (!p.spikes.length) spikes.append(el('p', 'No spike story is recorded for this page on the replay day.', 'metric-note'));
  for (const s of p.spikes) {
    const block = el('section', undefined, 'spike-block');
    block.append(el('h3', `Spike at ${utc(s.spike_hour)}`));
    const at = s.views[s.hours.indexOf(s.spike_hour)];
    block.append(el('p', `${isNum(at) ? fmtInt.format(at) + ' views in the first hour of the spike. ' : ''}A spike is at least 1,000 views in an hour and at least 10 times the page's median over the previous 24 hours.`, 'metric-note'));
    const dl = el('dl');
    for (const key of ['last_hour', 'our_model']) {
      const lag = s.catch_lag_h?.[key];
      const div = el('div');
      div.append(el('dt', key === 'last_hour' ? 'Standard rule' : $('lookup-model-col').textContent),
        el('dd', !isNum(lag) ? NA : lag === 0 ? 'Stored from the spike’s first hour' : lag >= 24 ? 'Not stored within 24 hours' : `Stored ${lag} ${lag === 1 ? 'hour' : 'hours'} after the spike began`));
      dl.append(div);
    }
    block.append(dl, el('p', `Catch lag at ${fmtInt.format(p.cache_size)} article spaces, from the replay file. These records do not show whether either method expected the spike in advance.`, 'metric-note'));
    spikes.append(block);
  }

  const body = $('lookup-body');
  body.replaceChildren();
  for (const t of p.timeline) {
    if (!isNum(t.views) && !t.in_replay_day) continue;
    const tr = el('tr');
    const th = el('th', `${utc(t.hour)}${p.spikes.some(s => s.spike_hour === t.hour) ? ' · spike' : ''}`);
    th.scope = 'row';
    tr.append(th,
      el('td', isNum(t.views) ? fmtInt.format(t.views) : 'Not recorded', 'views'),
      el('td', t.rank ? `#${t.rank}` : t.views_source === 'spike_story' ? 'below top 50' : '—', 'views'));
    for (const key of ['last_hour', 'our_model']) { const td = el('td', undefined, 'cache'); td.append(badge(t.cached ? t.cached[key] : undefined)); tr.append(td); }
    body.append(tr);
  }
}

function drawPageChart(p) {
  const svg = $('lookup-chart');
  svg.replaceChildren();
  svg.setAttribute('viewBox', '0 0 760 330');
  const pts = p.timeline.map(t => ({ ...t, time: Date.parse(t.hour) }));
  const known = pts.filter(t => isNum(t.views));
  if (!known.length) return;
  const start = pts[0].time, end = pts.at(-1).time, span = Math.max(end - start, 3600000);
  const max = Math.max(...known.map(t => t.views));
  const top = Math.ceil(max / 1000) * 1000 || 1000;
  const L = 80, R = 720, T = 40, B = 250;
  const x = t => L + (t - start) / span * (R - L);
  const y = v => B - v / top * (B - T);
  svg.append(svgEl('title', { id: 'lookup-chart-title' }, `Recorded views of ${p.title}`),
    svgEl('desc', {}, 'Actual hourly views; gaps are hours with no record. Exact values are in the table below.'));
  for (const f of [0, 0.5, 1]) {
    svg.append(svgEl('line', { x1: L, x2: R, y1: y(top * f), y2: y(top * f), stroke: '#eaecf0' }),
      svgEl('text', { x: L - 8, y: y(top * f) + 4, 'text-anchor': 'end' }, fmtInt.format(top * f)));
  }
  svg.append(svgEl('text', { x: L, y: 22 }, 'Views per hour'));
  for (const s of p.spikes) {
    const sx = x(Date.parse(s.spike_hour));
    svg.append(svgEl('line', { x1: sx, x2: sx, y1: T - 6, y2: B, stroke: '#92502c', 'stroke-dasharray': '3 4' }),
      svgEl('text', { x: sx, y: T - 10, 'text-anchor': 'middle' }, 'spike'));
  }
  let d = '', prev = null;
  for (const t of known) {
    d += `${prev !== null && t.time - prev === 3600000 ? 'L' : 'M'}${x(t.time).toFixed(1)} ${y(t.views).toFixed(1)} `;
    prev = t.time;
  }
  svg.append(svgEl('path', { d, fill: 'none', stroke: '#202122', 'stroke-width': 2.2 }));
  for (const t of known) {
    const c = svgEl('circle', { cx: x(t.time), cy: y(t.views), r: 4, fill: t.cached ? '#36c' : '#fff', stroke: '#202122', 'stroke-width': 1.5 });
    c.append(svgEl('title', {}, `${utc(t.hour)}: ${fmtInt.format(t.views)} views${t.rank ? ` (#${t.rank})` : ' (spike record)'}`));
    svg.append(c);
  }
  const step = Math.max(1, Math.ceil(pts.length / 8));
  pts.forEach((t, i) => { if (i % step === 0 || i === pts.length - 1) svg.append(svgEl('text', { x: x(t.time), y: B + 18, 'text-anchor': 'middle' }, t.hour.slice(11, 16))); });
  svg.append(svgEl('text', { x: (L + R) / 2, y: 300, 'text-anchor': 'middle' }, 'Hour (UTC) · filled points: in that hour’s top 50 · open points: from the spike record'));
}

/* ------------------------------------------------------------------ start */
async function start() {
  showStatus('Loading results from the local API…');
  try {
    await initExplorer();
    showStatus('');
  } catch (e) {
    showStatus(`Could not reach the local API (${e.message}). Start it from the repository folder with: uvicorn api:app --port 8000, then open http://127.0.0.1:8000/. No substitute numbers are shown.`, true);
  }
  route();
}
$('retry').addEventListener('click', () => { rp.loading = null; lk.quickLoaded = false; start(); });
start();
