"""Endpoint tests for api.py + demo_api.py.   Run from the repo root:  python -m pytest tests/  (or python tests/test_api.py)

Checks status codes and that values match the published files (results.csv, value_metrics.csv,
hourly.csv, demo.json). Nothing here recomputes a result.
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from fastapi.testclient import TestClient  # noqa: E402

import api  # noqa: E402

client = TestClient(api.app)
client.__enter__()                          # run startup (loads every file once)


def get(url, status=200):
    r = client.get(url, follow_redirects=False)
    assert r.status_code == status, f"{url}: {r.status_code} {r.text[:200]}"
    return r


# ---------------------------------------------------------------- decision explorer

def test_compare_headline_100k_1h():
    d = get("/api/compare?cache_size=100000&horizon=1").json()
    m = d["methods"]
    assert round(m["xgboost"]["hit_rate"] * 100, 1) == 86.6
    assert round(m["last_hour"]["hit_rate"] * 100, 1) == 85.2
    assert round(m["oracle"]["hit_rate"] * 100, 1) == 89.8
    assert m["xgboost"]["ci_low"] < m["xgboost"]["hit_rate"] < m["xgboost"]["ci_high"]
    v = d["versus_standard"]
    assert round(v["miss_reduction_pct"], 1) == 9.4
    assert (v["hours_won"], v["hours"], v["hours_lost"]) == (72, 72, 0)
    h = d["hourly"]
    assert len(h["target_hours"]) == 72 == len(h["xgboost"]) == len(h["last_hour"]) == len(h["oracle"])
    assert h["target_hours"][0].endswith("Z") and h["target_hours"] == sorted(h["target_hours"])
    assert all(0 <= x <= 1 for k in ("xgboost", "last_hour", "oracle") for x in h[k])


def test_compare_100k_6h():
    d = get("/api/compare?cache_size=100000&horizon=6").json()
    assert round(d["versus_standard"]["miss_reduction_pct"], 1) == 17.1
    assert d["versus_standard"]["hours_won"] == d["versus_standard"]["hours"] == 67
    assert len(d["hourly"]["target_hours"]) == 67


def test_compare_every_setting_matches_results_csv():
    import csv
    rows = {(r["predictor"], int(r["cache_size"]), int(r["horizon"])): float(r["hit_rate"])
            for r in csv.DictReader(open(api.OUT / "results.csv", newline=""))}
    opts = get("/api/options").json()
    assert opts == {"cache_sizes": [1000, 10000, 100000], "horizons": [1, 2, 3, 6]}
    for size in opts["cache_sizes"]:
        for h in opts["horizons"]:
            d = get(f"/api/compare?cache_size={size}&horizon={h}").json()
            for key in ("xgboost", "last_hour", "oracle"):
                assert d["methods"][key]["hit_rate"] == rows[(key, size, h)]
            assert d["versus_standard"] is not None and len(d["hourly"]["target_hours"]) > 0


def test_compare_rejects_unknown_setting():
    get("/api/compare?cache_size=5000&horizon=1", 404)
    get("/api/compare?cache_size=100000&horizon=4", 404)
    get("/api/compare?cache_size=abc", 422)


# ---------------------------------------------------------------- page lookup

def test_pages_autocomplete():
    d = get("/api/pages?q=tom").json()
    assert d["pages"][0]["page"] == "Tom_Skerritt" and d["pages"][0]["has_spike"]
    assert get("/api/pages?q=Tom skerritt").json()["pages"][0]["page"] == "Tom_Skerritt"
    assert get("/api/pages?q=zzzz-no-such-page").json()["pages"] == []
    default = get("/api/pages").json()["pages"]
    assert default and default[0]["has_spike"]
    get("/api/pages?limit=0", 422)


def test_page_tom_skerritt():
    d = get("/api/page/Tom_Skerritt").json()
    assert d["title"] == "Tom Skerritt" and d["cache_size"] == 10000
    by_hour = {t["hour"]: t for t in d["timeline"]}
    assert by_hour["2026-10-22T21:00:00Z"]["views"] == 97628
    assert by_hour["2026-10-22T20:00:00Z"]["cached"] == {"last_hour": True, "our_model": True}
    assert by_hour["2026-10-22T00:00:00Z"]["views"] is None          # outside the top 50: unknown, not 0
    assert d["spikes"][0]["spike_hour"] == "2026-10-22T20:00:00Z"
    assert d["spikes"][0]["catch_lag_h"] == {"last_hour": 0, "our_model": 0}
    assert get("/api/page/Tom Skerritt").json()["page"] == "Tom_Skerritt"


def test_page_not_in_replay_is_404():
    r = get("/api/page/Definitely_Not_A_Page", 404)
    assert "not in the replay day" in r.json()["detail"]


def test_page_title_with_slash():
    assert get("/api/page/Fiji/").json()["page"] == "Fiji/"


# ---------------------------------------------------------------- existing endpoints still work

def test_existing_endpoints():
    demo = get("/api/demo").json()
    assert demo["day"] == "2026-10-22" and len(demo["hours"]) == 24
    hours = get("/api/hours").json()
    assert len(hours["hours"]) == 24 and hours["cache_size"] == 10000
    assert len(get("/api/hours/0").json()["top_pages"]) == 50
    get("/api/hours/24", 404)
    assert len(get("/api/spikes").json()) == len(demo["spikes"])
    assert get("/api/summary").json()["our_model_name"] == "xgboost"
    rows = get("/api/results?horizon=1&cache_size=100000").json()
    assert {r["predictor"] for r in rows} >= {"xgboost", "last_hour", "oracle"}


def test_static_and_front_end():
    assert get("/", 307).headers["location"] == "/demo/live.html"
    assert "live.js" in get("/demo/live.html").text
    assert "app.js" in get("/demo/").text                        # the guided walkthrough is untouched
    assert get("/demo.json").json()["day"] == "2026-10-22"
    assert get("/out/results.csv").text.startswith("predictor,")
    get("/charts/key_numbers.md")


if __name__ == "__main__":
    tests = [f for n, f in sorted(globals().items()) if n.startswith("test_")]
    for t in tests:
        t()
        print("ok  ", t.__name__)
    print(f"{len(tests)} passed")
