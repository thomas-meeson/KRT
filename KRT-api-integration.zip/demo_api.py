"""demo_api.py -- the interactive endpoints behind demo/live.html. Included by api.py.

Every number comes straight from the published files, loaded once at startup:
    demo.json               replay of 22 Oct 2026 (repo root; out/demo.json is used instead if present)
    out/results.csv         hit rate per method x cache size x hours ahead, with 95% intervals
    out/hourly.csv          hit rate per method x cache size x hours ahead x test hour
    out/value_metrics.csv   miss reduction, paired gain and hours won, model vs the standard rule

Nothing is recomputed or estimated here: values are looked up and passed through. Anything the
files don't contain is returned as null (and the front end shows "not available").

Endpoints:
    GET /api/compare?cache_size=100000&horizon=1   decision explorer: XGBoost vs standard rule vs
                                                   perfect foresight, intervals, % fewer misses,
                                                   hours won, and the hour-by-hour series
    GET /api/options                               cache sizes and horizons that have results
    GET /api/pages?q=tom&limit=10                  autocomplete over pages in the replay day
    GET /api/page/{title}                          one page's replay day: views, cache status per
                                                   method, and its spike story if it has one
"""
from __future__ import annotations

import csv
import json
from functools import lru_cache
from pathlib import Path

from fastapi import APIRouter, HTTPException, Query

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "out"

MODEL = "xgboost"          # "Our model" everywhere in the demo
STANDARD = "last_hour"     # the standard rule
ORACLE = "oracle"          # perfect foresight (the ceiling, not a usable method)
METHODS = {MODEL: "Our model (XGBoost)", STANDARD: "Standard rule", ORACLE: "Perfect foresight"}

router = APIRouter()


# ---------------------------------------------------------------- loading (once, then cached)

def demo_path() -> Path:
    """INTERFACES.md puts the replay at out/demo.json; this repo publishes it at the root."""
    for path in (OUT / "demo.json", ROOT / "demo.json"):
        if path.exists():
            return path
    raise HTTPException(503, "demo.json not found (looked in out/ and the repo root)")


@lru_cache(maxsize=1)
def load_demo() -> dict:
    return json.loads(demo_path().read_text(encoding="utf-8"))


def _csv(name: str) -> list[dict]:
    path = OUT / name
    if not path.exists():
        raise HTTPException(503, f"out/{name} not found")
    with path.open(newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def _num(value: str | None) -> float | None:
    try:
        return float(value) if value not in (None, "") else None
    except ValueError:
        return None


@lru_cache(maxsize=1)
def load_results() -> dict:
    """(predictor, cache_size, horizon) -> row of results.csv."""
    return {(r["predictor"], int(r["cache_size"]), int(r["horizon"])): r for r in _csv("results.csv")}


@lru_cache(maxsize=1)
def load_hourly() -> dict:
    """(predictor, cache_size, horizon) -> {target_hour: hit_rate}."""
    series: dict = {}
    for r in _csv("hourly.csv"):
        key = (r["predictor"], int(r["cache_size"]), int(r["horizon"]))
        series.setdefault(key, {})[r["target_hour"]] = _num(r["hit_rate"])
    return series


@lru_cache(maxsize=1)
def load_value_metrics() -> dict:
    """(model, cache_size, horizon) -> row of value_metrics.csv (empty if the file is absent)."""
    path = OUT / "value_metrics.csv"
    if not path.exists():
        return {}
    return {(r["model"], int(r["cache_size"]), int(r["horizon"])): r for r in _csv("value_metrics.csv")}


@lru_cache(maxsize=1)
def page_index() -> dict:
    """page -> what the replay day records about it: its hours in the top 50 and its spikes."""
    d = load_demo()
    index: dict = {}
    for i, hour in enumerate(d["hours"]):
        for rank, p in enumerate(sorted(hour["top_pages"], key=lambda x: -x["views"]), start=1):
            entry = index.setdefault(p["page"], {"hours": {}, "spikes": []})
            entry["hours"][hour["hour"]] = {"rank": rank, "views": p["views"], "cached": p.get("cached", {})}
    for s in d["spikes"]:
        index.setdefault(s["page"], {"hours": {}, "spikes": []})["spikes"].append(s)
    return index


def warm() -> None:
    """Load every file once, so the first visitor doesn't wait."""
    load_demo(), load_results(), load_hourly(), load_value_metrics(), page_index()


# ---------------------------------------------------------------- decision explorer

def _options() -> tuple[list[int], list[int]]:
    keys = [k for k in load_results() if k[0] == MODEL]
    return sorted({k[1] for k in keys}), sorted({k[2] for k in keys})


@router.get("/api/options")
def get_options():
    sizes, horizons = _options()
    return {"cache_sizes": sizes, "horizons": horizons}


@router.get("/api/compare")
def get_compare(cache_size: int = 100000, horizon: int = 1):
    sizes, horizons = _options()
    if cache_size not in sizes or horizon not in horizons:
        raise HTTPException(404, f"no results for cache_size={cache_size}, horizon={horizon}; "
                                 f"available cache sizes {sizes}, horizons {horizons}")
    results, hourly = load_results(), load_hourly()

    methods = {}
    for key, label in METHODS.items():
        r = results.get((key, cache_size, horizon))
        methods[key] = None if r is None else {
            "label": label,
            "hit_rate": _num(r["hit_rate"]),
            "ci_low": _num(r["hit_rate_ci_low"]),
            "ci_high": _num(r["hit_rate_ci_high"]),
            "median_catch_lag_h": _num(r.get("median_catch_lag_h")),
            "spike_hit_rate": _num(r.get("spike_hit_rate")),
            "n_hours": int(r["n_hours"]) if r.get("n_hours") else None,
        }

    v = load_value_metrics().get((MODEL, cache_size, horizon))
    versus = None if v is None else {
        "miss_rate": _num(v["miss_rate"]),
        "standard_miss_rate": _num(v["standard_miss_rate"]),
        "miss_reduction_pct": _num(v["miss_reduction_pct"]),       # % fewer requests to the main servers
        "gain_pts": _num(v["gain_pts"]),
        "paired_ci_low_pts": _num(v["paired_gain_ci_low_pts"]),
        "paired_ci_high_pts": _num(v["paired_gain_ci_high_pts"]),
        "gap_closed_pct": _num(v["gap_closed_pct"]),
        "hours": int(v["hours"]),
        "hours_won": int(v["hours_won"]),
        "hours_lost": int(v["hours_lost"]),
        "sign_test_p": _num(v["sign_test_p"]),
        "source": "out/value_metrics.csv",
    }

    # Hour-by-hour: only target hours present for every method, in time order.
    per_method = {k: hourly.get((k, cache_size, horizon), {}) for k in METHODS}
    shared = sorted(set.intersection(*(set(s) for s in per_method.values()))) if all(per_method.values()) else []
    series = {
        "target_hours": [h.replace(" ", "T") + "Z" for h in shared],
        **{k: [per_method[k][h] for h in shared] for k in METHODS},
        "source": "out/hourly.csv",
    }

    return {"cache_size": cache_size, "horizon": horizon, "methods": methods,
            "versus_standard": versus, "hourly": series,
            "sources": {"rates": "out/results.csv", "versus_standard": "out/value_metrics.csv",
                        "hourly": "out/hourly.csv"}}


# ---------------------------------------------------------------- page lookup

def _normalise(title: str) -> str:
    return title.strip().replace(" ", "_")


@router.get("/api/pages")
def get_pages(q: str = "", limit: int = Query(10, ge=1, le=50)):
    """Pages in the replay day whose title contains q (spaces or underscores, any case).
    With no q: the pages with spike stories, then the most-read pages."""
    index = page_index()
    needle = _normalise(q).lower()

    def summary(page: str) -> dict:
        e = index[page]
        return {"page": page, "title": page.replace("_", " "), "hours_in_top_50": len(e["hours"]),
                "peak_views_in_top_50": max((h["views"] for h in e["hours"].values()), default=None),
                "has_spike": bool(e["spikes"])}

    if needle:
        hits = [p for p in index if needle in p.lower()]
        hits.sort(key=lambda p: (not p.lower().startswith(needle), -len(index[p]["hours"]), p))
    else:
        hits = sorted(index, key=lambda p: (not index[p]["spikes"],
                                            -max((h["views"] for h in index[p]["hours"].values()), default=0)))
    return {"query": q, "total": len(hits), "pages": [summary(p) for p in hits[:limit]],
            "scope": "Only pages that appear in the replay day (the top 50 pages of each hour, "
                     "or a spike story) can be looked up."}


@router.get("/api/page/{title:path}")
def get_page(title: str):
    d = load_demo()
    index = page_index()
    page = _normalise(title)
    if page not in index:
        raise HTTPException(404, f"'{page.replace('_', ' ')}' is not in the replay day. Only pages in the "
                                 f"top 50 of some hour on {d['day']}, or with a spike story, are recorded.")
    entry = index[page]

    # Views per hour: from the top-50 leaderboard, else from the page's spike story.
    # Anything else is unknown (the page was below the top 50), never zero.
    spike_views = {}
    for s in entry["spikes"]:
        for h, v in zip(s["hours"], s["views"]):
            if v > 0:                      # INTERFACES.md: 0 = missing hour or past the end of data
                spike_views[h] = v
    hours = sorted({h["hour"] for h in d["hours"]} | set(spike_views))
    timeline = []
    for h in hours:
        top = entry["hours"].get(h)
        timeline.append({
            "hour": h,
            "in_replay_day": h.startswith(d["day"]),
            "views": top["views"] if top else spike_views.get(h),
            "views_source": "top_50" if top else ("spike_story" if h in spike_views else None),
            "rank": top["rank"] if top else None,
            "cached": {"last_hour": top["cached"].get("last_hour"), "our_model": top["cached"].get("our_model")}
                      if top else None,
        })

    return {"page": page, "title": page.replace("_", " "), "day": d["day"],
            "cache_size": d["cache_size"], "horizon": 1, "our_model_name": d.get("our_model_name"),
            "hours_in_top_50": len(entry["hours"]),
            "timeline": timeline,
            "spikes": [{"spike_hour": s["spike_hour"], "hours": s["hours"],
                        "views": [v if v > 0 else None for v in s["views"]],
                        "catch_lag_h": s.get("catch_lag_h", {})} for s in entry["spikes"]],
            "scope": f"Views are recorded only while the page is in an hour's top 50 (or within its spike "
                     f"story). Cache status is from the replay file: {d['cache_size']:,} article spaces, "
                     f"chosen 1 hour ahead."}
